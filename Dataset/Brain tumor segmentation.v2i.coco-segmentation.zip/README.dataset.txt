# Brain tumor segmentation > 2025-01-03 7:19pm
https://universe.roboflow.com/debajyoti-majee-omgzh/brain-tumor-segmentation-ga1cp

Provided by a Roboflow user
License: CC BY 4.0

